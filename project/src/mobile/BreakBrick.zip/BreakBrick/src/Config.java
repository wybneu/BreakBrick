
public class Config {
	public static final int screenWidth=240;
	public static final int screenHeight=320;
	
	public static final int ballWidth=12;
	public static final int ballHeight=12;
	
	public static final int longBarWidth=60;
	public static final int longBarHeight=7;
	public static final int barWidth=40;
	public static final int barHeight=7;
	public static final int shortBarWidth=20;
	public static final int shortBarHeight=7;
	
	public static final int brickWidth=18;
	public static final int brickHeight=10;
	public static final int countNum=100;
	public static final int defaultMaxLevel=3;
	public static final int maxScoreNum=10;
	public static final String maxLevel="maxLevelDB";
	public static final String level="levelDB";
	public static final String record="recordDB";
	public static final String download1="http://localhost:8080/BreakBrickServer/Update?lastLevel=";
	public static final String download="http://118.209.29.64:8080/BreakBrickServer/Update?lastLevel=";
	public static String playerName="Someone";
	public static boolean landscape=false;
	public static final String topScore1="http://localhost:8080/BreakBrickServer/Top10";
	public static final String topScore="http://118.209.29.64:8080/BreakBrickServer/Top10";
	public static int speed=5;
}
